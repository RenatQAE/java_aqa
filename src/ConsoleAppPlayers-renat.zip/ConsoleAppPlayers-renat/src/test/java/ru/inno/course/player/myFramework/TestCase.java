package ru.inno.course.player.myFramework;

public record TestCase(String name, TestFunction testFunction) {
}

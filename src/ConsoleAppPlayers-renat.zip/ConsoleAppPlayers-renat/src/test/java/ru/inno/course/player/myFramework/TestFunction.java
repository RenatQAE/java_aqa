package ru.inno.course.player.myFramework;


public interface TestFunction {

    void runTest() throws Exception;
}
